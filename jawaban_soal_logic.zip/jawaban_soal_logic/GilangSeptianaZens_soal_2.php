
<?php
    if(isset($_POST['hitung'])){
        $nama    =$_POST['nama'];
        $harga    =$_POST['harga'];
        $qty    =$_POST['qty'];
        $ul1 = $_POST['1000']*1000;
         $ul2 = $_POST['2000']*2000;
          $ul5 = $_POST['5000']*5000;
           $ul10 = $_POST['10000']*10000;
           $ul20 = $_POST['20000']*20000;
           $ul50 = $_POST['50000']*50000;
           $ul100 = $_POST['100000']*100000;
         $uang    =$ul1+$ul2+$ul5+$ul10+$ul20+$ul50+$ul100;
        $total    =$harga*$qty;
        $kembalian = $uang-$total;
        echo "
            <table border='1' cellpadding='4'>
                <tr>
                    <td>Nama Barang</td>
                    <td>Harga</td>
                    <td>Banyaknya</td>
                    <td>Total Harga</td>
                    <td>Uang tersedia</td>
                        <td>Kembalian</td>

                </tr>
                <tr>
                    <td>$nama</td>
                    <td align='right'>";echo number_format($harga,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($qty,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($total,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($uang,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($kembalian,0,',','.');echo "</td>
                </tr>
            </table>
        ";
    }
?> 

<html>
<head>
    <title>Aplikasi untuk Soal Logic no.2 - Gilang Septiana Zens</title>
</head>

<body>
    <h3>Form Hitung </h3>
    <form method="POST">
        <table>
            <tr>
                <tr>
                <td>Uang Lembaran</td>
                <td>:</td>
                <td>
                    <select name="1000">
                        <option value="">- Uang Pecahan 1000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                     <select name="2000">
                        <option value="">- Uang Pecahan 2000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                   
                     <select name="5000">
                        <option value="">- Uang Pecahan 5000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                     <select name="10000">
                        <option value="">- Uang Pecahan 10000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                     <select name="20000">
                        <option value="">- Uang Pecahan 20000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                     <select name="50000">
                        <option value="">- Uang Pecahan 50000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                     <select name="100000">
                        <option value="">- Uang Pecahan 100000 -</option>
                        <?php
                            for($x=0;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                </td>
            </tr>
                <td>Nama Barang</td>
                <td>:</td>
                <td><input type="text" name="nama"></td>
            </tr>
            <tr>
                <td>Harga</td>
                <td>:</td>
                <td><input type="text" name="harga"></td>
            </tr>
            
            <tr>
                <td>Jumlah Item Barang</td>
                <td>:</td>
                <td>
                    <select name="qty">
                        <option value="">- Jumlah -</option>
                        <?php
                            for($x=1;$x<=50;$x++){
                        ?>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                </td>
            </tr>
            
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="hitung" value="Hitung">
                    <input type="reset" name="reset" value="Reset">
                </td>
            </tr>
        </table>
    </form>
    <hr />
  
   
</body>
</html>