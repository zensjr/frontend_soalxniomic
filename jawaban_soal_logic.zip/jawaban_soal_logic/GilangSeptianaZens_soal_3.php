
<?php
    if(isset($_POST['hitung'])){
        $cabang0    =$_POST['cabang0'];
        $cabang1    =$_POST['cabang1'];
        $cabang2    =$_POST['cabang2'];
        $pengeluaran    =$_POST['pengeluaran'];
        $akar = $cabang1-1;
        $r4 = $cabang2-1;
        $r = $pengeluaran/$cabang0;
        $r2 = sqrt($r);
        $r3 = pow($r2, $r4);
        $hasil    = $cabang0*$r3;
       
        echo "
            <table border='1' cellpadding='4'>
                <tr>
                    <td>cabang 1</td>
                    <td>cabang yang di ketahui</td>
                    <td>Pengeluaran</td>
                    <td>cabang yang ingin diketahui</td>
                    <td>pengeluaran</td>
                        

                </tr>
                <tr>
                   
                    <td align='right'>";echo number_format($cabang0,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($cabang1,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($pengeluaran,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($cabang2,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($hasil,0,',','.');echo "</td>
                </tr>
            </table>
        ";
    }
?> 

<html>
<head>
    <title>Aplikasi untuk Soal Logic no.3 - Gilang Septiana Zens</title>
</head>

<body>
    <h3>Form Hitung Peneluaran Cabang Toko Kelontong</h3>
    <form method="POST">
        <table>
             <tr>
                <td>Pengeluaran cabang pertama</td>
                <td>:</td>
                <td><input type="text" name="cabang0"></td>
            </tr>
            <tr>
                <td>Cabang pengeluaran diketahui</td>
                <td>:</td>
                <td><input type="text" name="cabang1"></td>
            </tr>
            <tr>
                <td>pengeluaran cabang yang diketahui</td>
                <td>:</td>
                <td><input type="text" name="pengeluaran"></td>
            </tr>
            
            <tr>
                <td>cabang pengeluaran yang ingin diketahui</td>
                <td>:</td>
                <td><input type="text" name="cabang2"></td>
            </tr>
           
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="hitung" value="Hitung">
                    <input type="reset" name="reset" value="Reset">
                </td>
            </tr>
        </table>
    </form>
    <hr />
  
   
</body>
</html>