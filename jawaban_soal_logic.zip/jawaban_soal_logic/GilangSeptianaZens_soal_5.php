
<?php
    if(isset($_POST['hitung'])){
        $makanan    =$_POST['makanan'];
        $minuman    =$_POST['minuman'];
        $parsel    =$_POST['parsel'];
       
        echo "
            <table border='1' cellpadding='4'>
                <tr>
                    <td>Menu Makanan</td>
                    <td>Menu Minuman</td>
                    <td>Menu Parsel</td>
                    

                </tr>
                <tr>
                    <td>$nama</td>
                    <td align='right'>";echo number_format($makanan,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($minuman,0,',','.');echo "</td>
                    <td align='right'>";echo number_format($parsel,0,',','.');echo "</td>
                    
                </tr>
            </table>
        ";
    }
?> 

<html>
<head>
    <title>Aplikasi untuk Soal Logic no.5 - Gilang Septiana Zens</title>
</head>

<body>
    <h3>Form Menu Makanan </h3>
    <form method="POST">
        <table>
            <tr>
                <tr>
                <td>Menu Makanan</td>
                <td>:</td>
                <td>
                    <select name="makanan">
                        <option value="menu makanan ke 1">Menu Makanan ke 1</option>
                        <option value="menu makanan ke 2">Menu Makanan ke 2</option>
                         <option value="menu makanan ke 3">Menu Makanan ke 3</option>
                          <option value="menu makanan ke 4">Menu Makanan ke 4</option>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                   <td>Menu Minuman</td>
                <td>:</td>
                <td>
                    <select name="minuman">
                        <option value="menu minuman ke 1">Menu Minuman ke 1</option>
                        <option value="menu minuman ke 2">Menu Minuman ke 2</option>
                         <option value="menu minuman ke 3">Menu Minuman ke 3</option>
                          <option value="menu minuman ke 4">Menu Minuman ke 4</option>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>
                    <td>Menu parsel</td>
                <td>:</td>
                <td>
                    <select name="parsel">
                        <option value="menu parsel ke 1">Menu Parsel ke 1</option>
                        <option value="menu parsel ke 2">Menu Parsel ke 2</option>
                         <option value="menu parsel ke 3">Menu Parsel ke 3</option>
                          <option value="menu parsel ke 4">Menu Parsel ke 4</option>
                        <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                        <?php
                            }
                        ?>
                    </select>  
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="hitung" value="Hitung">
                    <input type="reset" name="reset" value="Reset">
                </td>
            </tr>
        </table>
    </form>
    <hr />
  
   
</body>
</html>