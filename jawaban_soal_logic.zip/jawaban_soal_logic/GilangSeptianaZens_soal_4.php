<?php
if(isset($_POST['hitung'])){
$bil=$_POST['bil']; // Inisialisasi variabel bil dengan nilai 10

if ($bil % 2 == 0){ //Kondisi
    echo "$bil Merupakan Bilangan Genap"; //Kondisi true
}else {
    echo "$bil Merupakan Bilangan Ganjil"; //Kondisi false
}
    }
?> 

<html>
<head>
    <title>Aplikasi untuk Soal Logic no.4 - Gilang Septiana Zens</title>
</head>

<body>
    <h3>Form Bilangan ganjil atau Genap</h3>
    <form method="POST">
        <table>
            <tr>
                <td>Input Bilangan</td>
                <td>:</td>
                <td><input type="text" name="bil"></td>
            </tr>
           
                <td></td>
                <td></td>
                <td>
                    <input type="submit" name="hitung" value="Hitung">
                    <input type="reset" name="reset" value="Reset">
                </td>
            </tr>
        </table>
    </form>
    <hr />
  
   
</body>
</html>